export const largeNumber = 356;

// module.exports = {
//     largeNumber: largeNumber
// }
