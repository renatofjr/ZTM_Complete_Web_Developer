// const script2 = require('./script2')
import { largeNumber } from './script2.js'

const a = largeNumber;
const b = 7

console.log(a,b)